﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Bank
{
    public partial class Account : Form
    {
        public Account()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-4IVH2D9\SQLEXPRESS;Initial Catalog=BankDB;Integrated Security=True");
            con.Open();
            SqlCommand cnn = new SqlCommand("insert into accounts values( @account_id,@account_type,@balance,@date_opened,@customer_name)", con);
            cnn.Parameters.AddWithValue("@Account_ID", int.Parse(textBox2.Text));
            cnn.Parameters.AddWithValue("@Account_Type", textBox3.Text);
            cnn.Parameters.AddWithValue("@Balance", textBox4.Text);
            cnn.Parameters.AddWithValue("@Date_Opened", dateTimePicker1.Value);
            cnn.Parameters.AddWithValue("@Customer_Name", textBox5.Text);
            cnn.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Record Saved Successfully");
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-4IVH2D9\SQLEXPRESS;Initial Catalog=BankDB;Integrated Security=True");
            con.Open();
            SqlCommand cnn = new SqlCommand("select * from accounts", con);
            SqlDataAdapter da = new SqlDataAdapter(cnn);
            DataTable table = new DataTable();
            da.Fill(table);
            dataGridView1.DataSource = table;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-4IVH2D9\SQLEXPRESS;Initial Catalog=BankDB;Integrated Security=True");
            con.Open();
            SqlCommand cnn = new SqlCommand("UPDATE accounts SET account_type=@account_type, balence=@balence, date_opened=@date_opened, customer_name=@customer_name WHERE account_id=@account_id", con);
            cnn.Parameters.AddWithValue("@account_id", int.Parse(textBox2.Text));
            cnn.Parameters.AddWithValue("@account_type", textBox3.Text);
            cnn.Parameters.AddWithValue("@balence", textBox4.Text);
            cnn.Parameters.AddWithValue("@date_opened", dateTimePicker1.Value);
            cnn.Parameters.AddWithValue("@customer_name", textBox5.Text);
            cnn.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Record Updated Successfully!");
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-4IVH2D9\SQLEXPRESS;Initial Catalog=BankDB;Integrated Security=True");
            con.Open();
            SqlCommand cnn = new SqlCommand("delete accounts where account_id=@account_id", con);
            cnn.Parameters.AddWithValue("@Account_ID", int.Parse(textBox2.Text));
            cnn.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Record Deleted Successfully!");
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            dateTimePicker1.CustomFormat = "dd/MM/yyyy";
        }

        private void dateTimePicker1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Back)
            {
                dateTimePicker1.CustomFormat = "";
            }
        }

        private void Account_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-4IVH2D9\SQLEXPRESS;Initial Catalog=BankDB;Integrated Security=True");
            con.Open();
            SqlCommand cnn = new SqlCommand("select * from accounts", con);
            SqlDataAdapter da = new SqlDataAdapter(cnn);
            DataTable table = new DataTable();
            da.Fill(table);
            dataGridView1.DataSource = table;
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-4IVH2D9\SQLEXPRESS;Initial Catalog=BankDB;Integrated Security=True");
            con.Open();
            SqlCommand cnn = new SqlCommand("select * from accounts where account_id=@account_id", con);
            cnn.Parameters.AddWithValue("@Account_ID", int.Parse(textBox1.Text));
            SqlDataAdapter da = new SqlDataAdapter(cnn);
            DataTable table = new DataTable();
            da.Fill(table);
            con.Close();
            dataGridView1.DataSource = table;


        }
    }
}
